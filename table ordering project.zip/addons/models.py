from django.db import models
from django.contrib.auth.models import User


class Addon(models.Model):
    name = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    image = models.ImageField(upload_to='addon_images/', blank=True, null=True)

    def __str__(self):
        return f"{self.name} (${self.price})"


class Basket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    filling = models.ForeignKey(Filling, on_delete=models.SET_NULL, null=True, blank=True)
    addons = models.ManyToManyField(Addon, blank=True)
    quantity = models.PositiveIntegerField(default=1)
    special_instructions = models.TextField(blank=True, null=True)

    def total_price(self):
        item_price = self.menu_item.price
        filling_price = self.filling.extra_price if self.filling else 0
        addons_price = sum(addon.price for addon in self.addons.all())
        return (item_price + filling_price + addons_price) * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.menu_item.name} (User {self.user.username})"
