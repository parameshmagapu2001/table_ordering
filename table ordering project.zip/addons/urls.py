from django.urls import path
from . import views

urlpatterns = [
    path('menu/<int:item_id>/', views.menu_item_detail, name='menu_item_detail'),
    path('basket/add/<int:item_id>/', views.add_to_basket, name='add_to_basket'),
    path('basket/', views.view_basket, name='view_basket'),
]
