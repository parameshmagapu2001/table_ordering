from django.shortcuts import render, get_object_or_404, redirect
from .models import Basket
from menu.models import MenuItem, Addon, Filling  # Assuming they're in the menu app
from django.contrib.auth.decorators import login_required

@login_required
def add_to_basket(request, item_id):
    menu_item = get_object_or_404(MenuItem, id=item_id)
    filling_id = request.POST.get('filling')
    addons_ids = request.POST.getlist('addons')
    quantity = int(request.POST.get('quantity', 1))
    special_instructions = request.POST.get('special_instructions', '')

    # Get the selected filling, if any
    filling = Filling.objects.filter(id=filling_id).first()

    # Get selected addons
    addons = Addon.objects.filter(id__in=addons_ids)

    # Create or update the basket item
    basket_item, created = Basket.objects.get_or_create(
        user=request.user,
        menu_item=menu_item,
        filling=filling,
        special_instructions=special_instructions,
        defaults={'quantity': quantity}
    )

    if not created:
        basket_item.quantity += quantity
        basket_item.save()

    # Add selected addons
    basket_item.addons.set(addons)

    return redirect('view_basket')

@login_required
def view_basket(request):
    basket_items = Basket.objects.filter(user=request.user)
    total_price = sum([item.total_price() for item in basket_items])

    return render(request, 'cart/view_basket.html', {
        'basket_items': basket_items,
        'total_price': total_price
    })

@login_required
def remove_from_basket(request, item_id):
    basket_item = get_object_or_404(Basket, id=item_id, user=request.user)
    basket_item.delete()
    return redirect('view_basket')
