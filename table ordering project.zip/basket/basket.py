from orders.models import MenuItem, Addon, Basket, Profile

class BasketHandler():
    def __init__(self, request):
        """
        Initialize the basket for the user, using session data.
        If no basket exists, create an empty one.
        """
        self.session = request.session
        self.request = request
        basket = self.session.get('basket_session_key')

        # If no basket is found in the session, create an empty one.
        if 'basket_session_key' not in self.session:
            basket = self.session['basket_session_key'] = {}

        self.basket = basket

    def db_add(self, menu_item, quantity, addons=None):
        """
        Add menu items to the session-based basket, and sync with the user's Profile if authenticated.
        """
        menu_item_id = str(menu_item.id)
        item_qty = str(quantity)
        addons = addons or []  # Handle the case where no addons are passed  
        # Add the menu item to the basket if it doesn't already exist
        if menu_item_id not in self.basket:
            self.basket[menu_item_id] = {
                'quantity': int(item_qty), 
                'addons': [str(addon.id) for addon in addons]
            }

        # Mark the session as modified so Django saves it
        self.session.modified = True

        # If the user is authenticated, save the basket in their Profile
        if self.request.user.is_authenticated:
            current_user = Profile.objects.filter(user__id=self.request.user.id)
            basket_data = str(self.basket).replace("'", "\"")  # Convert dict to string
            current_user.update(old_basket=basket_data)

    def add(self, menu_item, quantity, addons=None):
        """
        Same as db_add but more generic, adds items and handles session.
        """
        menu_item_id = str(menu_item.id)
        item_qty = str(quantity)
        addons = addons or []

        # Add the menu item to the session basket
        if menu_item_id not in self.basket:
            self.basket[menu_item_id] = {
                'quantity': int(item_qty), 
                'addons': [str(addon.id) for addon in addons]
            }

        self.session.modified = True

        if self.request.user.is_authenticated:
            current_user = Profile.objects.filter(user__id=self.request.user.id)
            basket_data = str(self.basket).replace("'", "\"")
            current_user.update(old_basket=basket_data)

    def basket_total(self):
        """
        Calculate the total price of all items in the basket including addons.
        """
        menu_item_ids = self.basket.keys()
        menu_items = MenuItem.objects.filter(id__in=menu_item_ids)
        total = 0

        # Iterate through the basket and calculate total price including addons
        for key, value in self.basket.items():
            key = int(key)
            for menu_item in menu_items:
                if menu_item.id == key:
                    # Calculate total price of the item
                    item_total = menu_item.price * value['quantity']
                    
                    # Calculate total price of addons
                    addons_total = sum(Addon.objects.get(id=int(addon_id)).price for addon_id in value['addons']) * value['quantity']
        
                    # Add the item and addons total to the overall total
                    total += item_total + addons_total

        return total

    def __len__(self):
        """
        Return the number of unique items in the basket.
        """
        return len(self.basket)

    def get_items(self):
        """
        Retrieve all MenuItem objects stored in the basket.
        """
        menu_item_ids = self.basket.keys()
        menu_items = MenuItem.objects.filter(id__in=menu_item_ids)
        return menu_items

    def get_quantities(self):
        """
        Return a dictionary of quantities for each item in the basket.
        """
        quantities = {item_id: value['quantity'] for item_id, value in self.basket.items()}
        return quantities

    def update(self, menu_item, quantity, addons=None):
        """
        Update the quantity and addons for a specific menu item in the basket.
        """
        menu_item_id = str(menu_item.id)
        item_qty = int(quantity)
        addons = addons or []

        # Update the quantity and addons for the specific menu item
        self.basket[menu_item_id] = {
            'quantity': item_qty, 
            'addons': [str(addon.id) for addon in addons]
        }

        # Mark session as modified
        self.session.modified = True

        # Update the authenticated user's basket in their Profile
        if self.request.user.is_authenticated:
            current_user = Profile.objects.filter(user__id=self.request.user.id)
            basket_data = str(self.basket).replace("'", "\"")
            current_user.update(old_basket=basket_data)

    def delete(self, menu_item):
        """
        Remove a specific menu item from the basket.
        """
        menu_item_id = str(menu_item.id)
        
        # Remove the menu item from the basket
        if menu_item_id in self.basket:
            del self.basket[menu_item_id]

        # Mark session as modified
        self.session.modified = True

        # Update the user's Profile if authenticated
        if self.request.user.is_authenticated:
            current_user = Profile.objects.filter(user__id=self.request.user.id)
            basket_data = str(self.basket).replace("'", "\"")
            current_user.update(old_basket=basket_data)
