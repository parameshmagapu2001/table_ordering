
document.getElementById('basket-add-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const formData = new FormData(this); 
    fetch("{% url 'basket_add' %}", {
        method: "POST",
        body: formData,
        headers: {
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            alert("Item added to basket");
            location1331.reload();
        }
    });
});

document.querySelectorAll('.basket-update-form').forEach(function(form) {
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const basketId = this.getAttribute('data-id');
        const formData = new FormData(this);
        
        fetch("{% url 'basket_update' %}", {
            method: "POST",
            body: formData,
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                alert("Basket updated");
                location.reload();
            }
        });
    });
});

document.querySelectorAll('.basket-delete-form').forEach(function(form) {
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const basketId = this.getAttribute('data-id');
        
        fetch("{% url 'basket_delete' %}", {
            method: "POST",
            body: new URLSearchParams({'action': 'post', 'basket_id': basketId}),
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                alert("Item removed from basket");
                location.reload();
            }
        });
    });
});
