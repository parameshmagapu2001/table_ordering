from .basket import basket


def basket(request):

	return {'basket': basket(request)}