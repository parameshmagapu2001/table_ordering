from django.db import models
from django.contrib.auth.models import User
from menu.models import MenuItem, Addon, Filling  # Assuming these are in the 'menu' app

class Basket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='basket')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    filling = models.ForeignKey(Filling, on_delete=models.SET_NULL, null=True, blank=True)
    addons = models.ManyToManyField(Addon, blank=True)
    quantity = models.PositiveIntegerField(default=1)
    special_instructions = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.quantity} x {self.menu_item.name} ({self.user.username})"

    def total_price(self):
        item_total = self.quantity * self.menu_item.price
        addons_total = sum([addon.price for addon in self.addons.all()]) * self.quantity
        return item_total + addons_total
