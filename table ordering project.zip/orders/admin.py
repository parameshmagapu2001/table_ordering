from django.contrib import admin
from .models import Table, CustomUser, Category, MenuItem, Order, OrderItem

@admin.register(Table)
class TableAdmin(admin.ModelAdmin):
    list_display = ('number', 'seats', 'is_available')
    search_fields = ('number',)
    list_filter = ('is_available',)

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('name', 'table', 'contact_number')
    search_fields = ('name', 'contact_number')
    list_filter = ('table',)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'table', 'status')
    search_fields = ('user__name', 'status')
    list_filter = ('status',)

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'menu_item', 'quantity')
    search_fields = ('order__id', 'menu_item__name')

# Register MenuItemAdmin with image preview
@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'available', 'image_preview')  # Display a preview of the image in the admin list view
    search_fields = ('name',)
    list_filter = ('available',)
    fields = ('name', 'description', 'price', 'available', 'image')  # Fields displayed in the admin form

    # Method to display a thumbnail of the image in the admin list view
    def image_preview(self, obj):
        if obj.image:
            return f'<img src="{obj.image.url}" width="50" height="50" />'
        return 'No image'
    
    image_preview.allow_tags = True  # Allow HTML tags in the list_display column
    image_preview.short_description = 'Image Preview'
