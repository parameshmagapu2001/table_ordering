from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Table, CustomUser, Category, MenuItem, Order, OrderItem

class TableListView(ListView):
    model = Table
    template_name = 'tables/table_list.html'
    context_object_name = 'tables'

class TableDetailView(DetailView):
    model = Table
    template_name = 'tables/table_detail.html'
    context_object_name = 'table'

class TableCreateView(CreateView):
    model = Table
    fields = ['number', 'seats', 'is_available']
    template_name = 'tables/table_form.html'
    success_url = reverse_lazy('table_list')

class TableUpdateView(UpdateView):
    model = Table
    fields = ['number', 'seats', 'is_available']
    template_name = 'tables/table_form.html'
    success_url = reverse_lazy('table_list')

class TableDeleteView(DeleteView):
    model = Table
    template_name = 'tables/table_confirm_delete.html'
    success_url = reverse_lazy('table_list')

class CustomUserListView(ListView):
    model = CustomUser
    template_name = 'users/customuser_list.html'
    context_object_name = 'users'

class CustomUserDetailView(DetailView):
    model = CustomUser
    template_name = 'users/customuser_detail.html'
    context_object_name = 'user'

class CustomUserCreateView(CreateView):
    model = CustomUser
    fields = ['name', 'table', 'contact_number']
    template_name = 'users/customuser_form.html'
    success_url = reverse_lazy('customuser_list')

class CustomUserUpdateView(UpdateView):
    model = CustomUser
    fields = ['name', 'table', 'contact_number']
    template_name = 'users/customuser_form.html'
    success_url = reverse_lazy('customuser_list')

class CustomUserDeleteView(DeleteView):
    model = CustomUser
    template_name = 'users/customuser_confirm_delete.html'
    success_url = reverse_lazy('customuser_list')


class CategoryListView(ListView):
    model = Category
    template_name = 'categories/category_list.html'
    context_object_name = 'categories'

class CategoryCreateView(CreateView):
    model = Category
    fields = ['name']
    template_name = 'categories/category_form.html'
    success_url = reverse_lazy('category_list')



class MenuItemListView(ListView):
    model = MenuItem
    template_name = 'menu_items/menuitem_list.html'
    context_object_name = 'menu_items'

class MenuItemDetailView(DetailView):
    model = MenuItem
    template_name = 'menu_items/menuitem_detail.html'
    context_object_name = 'menu_item'

class MenuItemCreateView(CreateView):
    model = MenuItem
    fields = ['name', 'description', 'price', 'image', 'available']
    template_name = 'menu_items/menuitem_form.html'
    success_url = reverse_lazy('menuitem_list')

class MenuItemUpdateView(UpdateView):
    model = MenuItem
    fields = ['name', 'description', 'price', 'image', 'available']
    template_name = 'menu_items/menuitem_form.html'
    success_url = reverse_lazy('menuitem_list')

class MenuItemDeleteView(DeleteView):
    model = MenuItem
    template_name = 'menu_items/menuitem_confirm_delete.html'
    success_url = reverse_lazy('menuitem_list')


class OrderListView(ListView):
    model = Order
    template_name = 'orders/order_list.html'
    context_object_name = 'orders'

class OrderDetailView(DetailView):
    model = Order
    template_name = 'orders/order_detail.html'
    context_object_name = 'order'

class OrderCreateView(CreateView):
    model = Order
    fields = ['user', 'table', 'status']
    template_name = 'orders/order_form.html'
    success_url = reverse_lazy('order_list')

class OrderUpdateView(UpdateView):
    model = Order
    fields = ['user', 'table', 'status']
    template_name = 'orders/order_form.html'
    success_url = reverse_lazy('order_list')

class OrderDeleteView(DeleteView):
    model = Order
    template_name = 'orders/order_confirm_delete.html'
    success_url = reverse_lazy('order_list')


class OrderItemListView(ListView):
    model = OrderItem
    template_name = 'order_items/orderitem_list.html'
    context_object_name = 'order_items'

class OrderItemCreateView(CreateView):
    model = OrderItem
    fields = ['order', 'menu_item', 'quantity']
    template_name = 'order_items/orderitem_form.html'
    success_url = reverse_lazy('orderitem_list')

class OrderItemUpdateView(UpdateView):
    model = OrderItem
    fields = ['order', 'menu_item', 'quantity']
    template_name = 'order_items/orderitem_form.html'
    success_url = reverse_lazy('orderitem_list')

class OrderItemDeleteView(DeleteView):
    model = OrderItem
    template_name = 'order_items/orderitem_confirm_delete.html'
    success_url = reverse_lazy('orderitem_list')

