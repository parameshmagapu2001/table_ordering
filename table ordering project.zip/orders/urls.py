from django.urls import path
from .views import (TableListView, TableDetailView, TableCreateView, TableUpdateView, TableDeleteView,
                    CustomUserListView, CustomUserDetailView, CustomUserCreateView, CustomUserUpdateView, CustomUserDeleteView,
                    CategoryListView, CategoryCreateView,
                    MenuItemListView, MenuItemDetailView, MenuItemCreateView, MenuItemUpdateView, MenuItemDeleteView,
                    OrderListView, OrderDetailView, OrderCreateView, OrderUpdateView, OrderDeleteView,
                    OrderItemListView, OrderItemCreateView, OrderItemUpdateView, OrderItemDeleteView)

urlpatterns = [
    path('tables/', TableListView.as_view(), name='table_list'),
    path('tables/<int:pk>/', TableDetailView.as_view(), name='table_detail'),
    path('tables/create/', TableCreateView.as_view(), name='table_create'),
    path('tables/<int:pk>/update/', TableUpdateView.as_view(), name='table_update'),
    path('tables/<int:pk>/delete/', TableDeleteView.as_view(), name='table_delete'),

    path('users/', CustomUserListView.as_view(), name='customuser_list'),
    path('users/<int:pk>/', CustomUserDetailView.as_view(), name='customuser_detail'),
    path('users/create/', CustomUserCreateView.as_view(), name='customuser_create'),
    path('users/<int:pk>/update/', CustomUserUpdateView.as_view(), name='customuser_update'),
    path('users/<int:pk>/delete/', CustomUserDeleteView.as_view(), name='customuser_delete'),

    path('categories/', CategoryListView.as_view(), name='category_list'),
    path('categories/create/', CategoryCreateView.as_view(), name='category_create'),

    path('menu-items/', MenuItemListView.as_view(), name='menuitem_list'),
    path('menu-items/<int:pk>/', MenuItemDetailView.as_view(), name='menuitem_detail'),
    path('menu-items/create/', MenuItemCreateView.as_view(), name='menuitem_create'),
    path('menu-items/<int:pk>/update/', MenuItemUpdateView.as_view(), name='menuitem_update'),
    path('menu-items/<int:pk>/delete/', MenuItemDeleteView.as_view(), name='menuitem_delete'),

    path('orders/', OrderListView.as_view(), name='order_list'),
    path('orders/<int:pk>/', OrderDetailView.as_view(), name='order_detail'),
    path('orders/create/', OrderCreateView.as_view(), name='order_create'),
    path('orders/<int:pk>/update/', OrderUpdateView.as_view(), name='order_update'),
    path('orders/<int:pk>/delete/', OrderDeleteView.as_view(), name='order_delete'),

    path('order-items/', OrderItemListView.as_view(), name='orderitem_list'),
    path('order-items/create/', OrderItemCreateView.as_view(), name='orderitem_create'),
    path('order-items/<int:pk>/update/', OrderItemUpdateView.as_view(), name='orderitem_update'),
    path('order-items/<int:pk>/delete/', OrderItemDeleteView.as_view(), name='orderitem_delete'),
]
